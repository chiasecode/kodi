def autorun_addon():
    from kodi_six import xbmc, xbmcaddon
    if xbmcaddon.Addon().getSetting("auto_run") == "true":
        xbmc.executebuiltin('RunAddon(plugin.video.vnmedia)')
    return
autorun_addon()