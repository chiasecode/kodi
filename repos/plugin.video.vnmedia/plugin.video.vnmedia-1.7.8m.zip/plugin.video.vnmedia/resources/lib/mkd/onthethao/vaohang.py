from codequick import Route, Listitem, run
from resources.lib.kedon import quangcao, getlink, stream, referer, play_vnm, qc
@Route.register
def index_vaohang(plugin, **kwargs):
	ux = 'https://vaohang.com/api/statistical/tat_ca'
	resp = getlink(ux, ux, 6*60)
	if resp is not None:
		if '.m3u8' in resp.text:
			kq = resp.json()
			for m in kq['data']:
				item = Listitem()
				linktrandau = m['link_live']
				if '.m3u8' in linktrandau:
					linkplay = linktrandau
				else:
					linkplay = stream(qc)
				doi1 = m['name_away']
				doi2 = m['name_home']
				thoigian = m['date']
				tentrandau = f'{thoigian}: {doi1}-{doi2}'
				blv = m['blv']
				if blv:
					item.label = f'{tentrandau} - BLV: {blv}'
				else:
					item.label = tentrandau
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://vaohang2.tv/wp-content/uploads/2022/07/logo.png'
				item.set_callback(play_vnm, linkplay, item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()