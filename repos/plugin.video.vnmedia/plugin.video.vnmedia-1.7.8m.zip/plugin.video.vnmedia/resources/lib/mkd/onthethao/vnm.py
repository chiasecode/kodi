from codequick import Route, Listitem, run
@Route.register
def index_vnm(plugin, **kwargs):
	from resources.lib.kedon import getlink, stream, ace, play_vnm, quangcao, tb
	url = 'https://mi3s.top/vnmedia'
	resp = getlink(url, url, 300)
	if resp is not None:
		import urllib.parse
		tach = resp.text.split('\n')
		for k in tach:
			item = Listitem()
			tachhat = k.split('|')
			if len(tachhat)>1:
				kenh = urllib.parse.unquote(tachhat[1])
				item.label = tachhat[0].replace('*','')
				item.info['plot'] = tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = tachhat[3]
				if 'acestream' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				elif ':6878' in kenh:
					linkplay = ace(kenh, item.label)
					item.path = linkplay
					item.set_callback(item.path)
				else:
					linkplay = stream(kenh.strip())
					item.set_callback(play_vnm, linkplay, item.label, '')
				yield item
	else:
		yield quangcao()