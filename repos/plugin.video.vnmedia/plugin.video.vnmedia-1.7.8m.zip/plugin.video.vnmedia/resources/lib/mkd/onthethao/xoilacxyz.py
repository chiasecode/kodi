from codequick import Route, Listitem, run
def respxoilacxyz():
	from resources.lib.kedon import getlink, tiengruoi
	tr2 = tiengruoi()[2]
	resp90 = getlink(tr2, tr2, 0)
	if resp90 is not None:
		import re
		ref = re.search(r'  window.base_embed_url(.*?)"(.*?)"', resp90.text).group(2)
	else:
		ref = tr2
	return ref
@Route.register
def index_xoilacxyz(plugin, **kwargs):
	from resources.lib.kedon import getlink, quangcao, tb
	url = 'http://api.vebo.xyz/api/match/live'
	ref = respxoilacxyz()
	resp = getlink(url, ref, 1000)
	if resp is not None:
		import datetime
		kq = resp.json()
		for k in kq['data']:
			item = Listitem()
			time = datetime.datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d-%m')
			idk = k['id']
			if k['commentators']:
				item.label = f'{time}: {k["name"]} ({k["commentators"][0]["name"]})'
			else:
				item.label = f'{time}: {k["name"]}'
			item.info['plot'] = tb
			item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://90m.link/images/logo-xoilac.png'
			item.set_callback(list_xoilacxyz, idk, item.label)
			yield item
	else:
		yield quangcao()
@Route.register
def list_xoilacxyz(plugin, idk, title, **kwargs):
	from resources.lib.kedon import getlink, stream, referer, play_vnm, quangcao, tb
	ref = respxoilacxyz()
	url = f'http://api.vebo.xyz/api/match/{idk}/meta'
	resp = getlink(url, ref, 400)
	if resp is not None:
		if '.m3u8' in resp.text:
			kq = resp.json()
			for k in kq['data']['play_urls']:
				item = Listitem()
				item.label = f'{k["name"]} - {title}'
				linktrandau = f'{stream(k["url"])}{referer(ref)}'
				item.info['plot'] = tb
				item.art['thumb'] = item.art['landscape'] = item.art['fanart'] = 'https://90m.link/images/logo-xoilac.png'
				item.set_callback(play_vnm, linktrandau, item.label, '')
				yield item
		else:
			yield quangcao()
	else:
		yield quangcao()